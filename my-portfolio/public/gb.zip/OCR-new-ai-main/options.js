// Saves options to chrome.storage
function save_options() {
  const apiKey = document.getElementById('api-key').value;
  const groqKey = document.getElementById('groq-api-key').value;
  
  chrome.storage.local.set({
    geminiApiKey: apiKey,
    groqApiKey: groqKey
  }, function () {
    const status = document.getElementById('status');
    status.textContent = 'API Keys saved!';
    setTimeout(function () {
      status.textContent = '';
    }, 1500);
  });
}

// Restores saved API key
function restore_options() {
  chrome.storage.local.get(['geminiApiKey', 'groqApiKey'], function (items) {
    if (items.geminiApiKey) {
      document.getElementById('api-key').value = items.geminiApiKey;
    }
    if (items.groqApiKey) {
      document.getElementById('groq-api-key').value = items.groqApiKey;
    }
  });
}

document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save-btn').addEventListener('click', save_options);
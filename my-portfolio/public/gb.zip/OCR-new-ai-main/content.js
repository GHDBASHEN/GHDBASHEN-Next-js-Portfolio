(function () {

  // If an old script is running, force it to clean up.

  if (window.geminiQuizHelperCleanup) {

    window.geminiQuizHelperCleanup();

  }

  // Prevent script from running multiple times if already active

  if (window.geminiQuizHelperActive) {

    return;

  }

  window.geminiQuizHelperActive = true;





  // --- This is the new cleanup function ---

  function cleanupAll() {

    chrome.runtime.onMessage.removeListener(messageListener); // Clean up listener

    window.geminiQuizHelperActive = false; // Reset flag

    delete window.geminiQuizHelperCleanup; // Remove self

  }



  // Assign to window so new scripts can kill this one

  window.geminiQuizHelperCleanup = cleanupAll;





  // 3. Message Listener

  const messageListener = (request, sender, sendResponse) => {

    // This script no longer receives "cropImage"



    if (request.type === "showAnswer") {

      hideLoadingBox();

      showAnswerBox(request.text, null); // Pass null for area

    } else if (request.type === "showError") {

      hideLoadingBox();

      showAnswerBox(request.text, null, true);

    } else if (request.type === "updateStatus") {

      updateLoadingStatus(request.text);

    }

    return true;

  };



  chrome.runtime.onMessage.addListener(messageListener);



  // 4. Helper functions

  function showLoadingBox(area) {
    const loadingBox = document.createElement('div');
    loadingBox.id = 'gemini-loading-box';
    loadingBox.style.display = 'none'; // Completely hidden during initialization
    document.body.appendChild(loadingBox);
  }



  function updateLoadingStatus(text) {

    const loadingBox = document.getElementById('gemini-loading-box');

    if (loadingBox) {

      loadingBox.innerText = text;

    }

  }



  function hideLoadingBox() {

    const loadingBox = document.getElementById('gemini-loading-box');

    if (loadingBox) loadingBox.remove();

  }



  function showAnswerBox(text, area, isError = false) {
    const answerBox = document.createElement('div');
    answerBox.id = 'gemini-stealth-answer';
    answerBox.style.position = 'fixed';
    
    // Bottom-left corner
    answerBox.style.left = '5px';
    answerBox.style.bottom = '5px';

    // Raw floating text, no window
    answerBox.style.maxWidth = '200px';
    answerBox.style.fontSize = '10px';
    answerBox.style.padding = '0';
    answerBox.style.background = 'transparent';
    answerBox.style.color = '#000'; // Black text
    // Subtle white outline so text is readable on dark pages
    answerBox.style.textShadow = '0 0 2px #fff, 0 0 2px #fff';
    answerBox.style.border = 'none';
    answerBox.style.borderRadius = '3px';
    answerBox.style.zIndex = '99999999';
    answerBox.style.fontFamily = 'monospace';
    answerBox.style.pointerEvents = 'none'; // so it doesn't block clicks
    
    // Smooth fade in
    answerBox.style.opacity = '0';
    answerBox.style.transition = 'opacity 0.5s ease-in-out';

    if (isError) answerBox.style.color = '#ff6666';

    answerBox.innerHTML = text.replace(/\n/g, '<br>');

    // FALLBACK 1: Always log to console just in case
    console.log("%c---- AI Answer ----", "color: #00ff00; font-size: 14px;");
    console.log(text);
    console.log("-------------------");

    let closeTimer = null;
    const closeBox = () => {
      if (closeTimer) clearTimeout(closeTimer);
      if (answerBox) answerBox.remove();
      cleanupAll();
    };

    document.body.appendChild(answerBox);
    
    // Trigger fade in
    setTimeout(() => { answerBox.style.opacity = '1'; }, 10);

    // Auto-close after 3 seconds
    closeTimer = setTimeout(closeBox, 3000); 
  }



  // --- All snipping/crop code is GONE ---



  // --- RUN AUTOMATICALLY ON START ---

  showLoadingBox(null);

  chrome.runtime.sendMessage({ type: "autoCapture" });



})();
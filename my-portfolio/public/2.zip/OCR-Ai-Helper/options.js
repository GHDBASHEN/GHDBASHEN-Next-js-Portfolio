// Saves options to chrome.storage
function save_options() {
  const apiKey = document.getElementById('api-key').value;
  // Save only as 'geminiApiKey'
  chrome.storage.local.set({
    geminiApiKey: apiKey
  }, function () {
    // Update status to let user know options were saved.
    const status = document.getElementById('status');
    status.textContent = 'API Keys saved!';
    setTimeout(function () {
      status.textContent = '';
    }, 1500);
  });
}

// Restores saved API key
function restore_options() {
  // Look for 'geminiApiKey'
  chrome.storage.local.get(['geminiApiKey'], function (items) {
    if (items.geminiApiKey) {
      document.getElementById('api-key').value = items.geminiApiKey;
    }
  });
}

document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save-btn').addEventListener('click', save_options);
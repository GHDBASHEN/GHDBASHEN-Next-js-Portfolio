// Function to start the "automatic" process

function startAutoCapture(tab) {

  // We still inject content.js, but it will have a new job

  chrome.scripting.executeScript({

    target: { tabId: tab.id },

    files: ['content.js']

  });

}



// Triggered when the user clicks the extension icon

chrome.action.onClicked.addListener((tab) => {

  startAutoCapture(tab);

});



// Triggered when the user presses the keyboard shortcut

chrome.commands.onCommand.addListener((command, tab) => {

  if (command === "start-selection") {

    startAutoCapture(tab);

  }

});



// Listens for messages from content.js

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {



  // --- NEW LOGIC ---

  // content.js will send this message immediately

  if (request.type === "autoCapture") {

    // Take a screenshot of the visible tab

    chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png" }, (dataUrl) => {

      if (chrome.runtime.lastError) {

        console.error(chrome.runtime.lastError.message);

        chrome.tabs.sendMessage(sender.tab.id, { type: "showError", text: "Error capturing screen." });

        return;

      }



      // We are NOT sending this to content.js to be cropped.

      // We send the full screenshot directly to the AI.



      // Remove the "data:image/png;base64," prefix for the API

      const base64Data = dataUrl.split(',')[1];



      // Call AI Flow with the full screenshot
      callAIFlow(base64Data, sender.tab.id);
    });

    return true; // Indicates we will send a response asynchronously

  }



  // This part is no longer used, but is safe to leave

  else if (request.type === "callGemini") {

    // This logic is now handled above

    return true;

  }

});



async function callAIFlow(imageDataBase64, tabId) {
  try {
    const { groqApiKey } = await chrome.storage.local.get(['groqApiKey']);

    if (!groqApiKey) {
      chrome.tabs.sendMessage(tabId, { type: "showError", text: "Groq API Key not set. Please set it in the extension options." });
      return;
    }

    // --- STEP 1: EXTRACT TEXT (GROQ VISION) ---
    chrome.tabs.sendMessage(tabId, { type: "updateStatus", text: "Extracting text (Groq)..." });
    const extractedText = await extractTextFromImageGroq(imageDataBase64, groqApiKey);

    if (!extractedText) {
      throw new Error("Could not extract text from screenshot.");
    }

    // --- STEP 2: GET ANSWER (GROQ LLM) ---
    chrome.tabs.sendMessage(tabId, { type: "updateStatus", text: "Getting answer (Groq)..." });
    const answerResponse = await getAnswerFromGroq(extractedText, groqApiKey);

    chrome.tabs.sendMessage(tabId, { type: "showAnswer", text: answerResponse });

  } catch (error) {
    console.error("Error in AI Flow:", error);
    chrome.tabs.sendMessage(tabId, { type: "showError", text: `Error: ${error.message}` });
  }
}

async function extractTextFromImageGroq(imageDataBase64, apiKey) {
  // Use supported Groq Vision models
  const models = ["meta-llama/llama-4-scout-17b-16e-instruct", "llama-3.2-11b-vision-preview"];
  let lastError;

  for (const model of models) {
    try {
      const API_URL = "https://api.groq.com/openai/v1/chat/completions";
      const prompt = `Extract all text from this screenshot. Find the main question and all possible options. 
      Output ONLY the extracted text in a clean format. No explanations.`;

      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          "model": model,
          "messages": [
            {
              "role": "user",
              "content": [
                { "type": "text", "text": prompt },
                {
                  "type": "image_url",
                  "image_url": {
                    "url": `data:image/png;base64,${imageDataBase64}`
                  }
                }
              ]
            }
          ]
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        const errorMessage = errorData.error?.message || "Unknown Groq Vision Error";

        if (response.status === 429 || response.status === 404) {
          console.warn(`Issue with ${model}: ${errorMessage}. Trying next...`);
          lastError = errorMessage;
          continue;
        }
        throw new Error(errorMessage);
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (e) {
      console.warn(`Groq Vision failed with ${model}: ${e.message}`);
      lastError = e.message;
    }
  }
  throw new Error(`Groq OCR Failed: ${lastError}`);
}

async function getAnswerFromGroq(extractedText, apiKey) {
  const API_URL = "https://api.groq.com/openai/v1/chat/completions";

  const body = {
    "model": "meta-llama/llama-4-scout-17b-16e-instruct",
    "messages": [
      {
        "role": "user",
        "content": `Based on the extracted text below, provide the question in short and the correct answer only. No explanation needed.\n\nExtracted Text:\n${extractedText}`
      }
    ]
  };

  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(`Groq LLM Error: ${errorData.error.message}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

# OCR-Ai-Helper
Creating OCR based AI system

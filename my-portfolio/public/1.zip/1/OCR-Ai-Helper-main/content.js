(function () {

  // If an old script is running, force it to clean up.

  if (window.geminiQuizHelperCleanup) {

    window.geminiQuizHelperCleanup();

  }

  // Prevent script from running multiple times if already active

  if (window.geminiQuizHelperActive) {

    return;

  }

  window.geminiQuizHelperActive = true;





  // --- This is the new cleanup function ---

  function cleanupAll() {

    chrome.runtime.onMessage.removeListener(messageListener); // Clean up listener

    window.geminiQuizHelperActive = false; // Reset flag

    delete window.geminiQuizHelperCleanup; // Remove self

  }



  // Assign to window so new scripts can kill this one

  window.geminiQuizHelperCleanup = cleanupAll;





  // 3. Message Listener

  const messageListener = (request, sender, sendResponse) => {

    // This script no longer receives "cropImage"



    if (request.type === "showAnswer") {

      hideLoadingBox();

      showAnswerBox(request.text, null); // Pass null for area

    } else if (request.type === "showError") {

      hideLoadingBox();

      showAnswerBox(request.text, null, true);

    } else if (request.type === "updateStatus") {

      updateLoadingStatus(request.text);

    }

    return true;

  };



  chrome.runtime.onMessage.addListener(messageListener);



  // 4. Helper functions

  function showLoadingBox(area) {

    const loadingBox = document.createElement('div');

    loadingBox.id = 'gemini-loading-box';

    loadingBox.style.position = 'fixed';



    // --- MODIFIED: Show in top-left corner ---

    loadingBox.style.left = '20px';

    loadingBox.style.top = '20px';



    loadingBox.style.padding = '2px 5px';

    loadingBox.style.fontSize = '5px';

    loadingBox.innerText = 'Initializing...';

    loadingBox.style.background = 'transparent';
    loadingBox.style.color = '#666';
    loadingBox.style.border = 'none';
    loadingBox.style.borderRadius = '5px';

    loadingBox.style.zIndex = '99999999';

    loadingBox.style.fontFamily = 'sans-serif';

    loadingBox.style.boxShadow = 'none';

    document.body.appendChild(loadingBox);

  }



  function updateLoadingStatus(text) {

    const loadingBox = document.getElementById('gemini-loading-box');

    if (loadingBox) {

      loadingBox.innerText = text;

    }

  }



  function hideLoadingBox() {

    const loadingBox = document.getElementById('gemini-loading-box');

    if (loadingBox) loadingBox.remove();

  }



  function showAnswerBox(text, area, isError = false) {

    const answerBox = document.createElement('div');

    answerBox.style.position = 'fixed';



    // --- MODIFIED: Show in top-left corner ---

    answerBox.style.left = '20px';

    answerBox.style.top = '20px';



    answerBox.style.maxWidth = '100px';

    answerBox.style.fontSize = '8px';

    answerBox.style.padding = '10px';



    answerBox.style.background = 'transparent';



    answerBox.style.border = 'none';

    answerBox.style.color = '#666';

    answerBox.style.borderRadius = '8px';

    answerBox.style.boxShadow = 'none';

    answerBox.style.zIndex = '99999999';

    answerBox.style.fontFamily = 'sans-serif';

    answerBox.style.lineHeight = '1.5';

    answerBox.style.cursor = 'default';



    answerBox.innerHTML = text.replace(/\n/g, '<br>');



    let closeTimer = null;



    const closeBtn = document.createElement('button');

    closeBtn.innerText = 'X';

    closeBtn.style.position = 'absolute';

    closeBtn.style.top = '5px';

    closeBtn.style.right = '5px';

    closeBtn.style.background = 'none';

    closeBtn.style.border = 'none';

    closeBtn.style.fontSize = '14px';

    closeBtn.style.color = '#777';

    closeBtn.style.cursor = 'pointer';



    const closeBox = () => {

      if (closeTimer) clearTimeout(closeTimer);

      if (answerBox) answerBox.remove();

      cleanupAll();

    };



    closeBtn.onclick = closeBox;

    answerBox.appendChild(closeBtn);

    document.body.appendChild(answerBox);



    closeTimer = setTimeout(closeBox, 5000); // 1000ms = 1 second

  }



  // --- All snipping/crop code is GONE ---



  // --- RUN AUTOMATICALLY ON START ---

  showLoadingBox(null);

  chrome.runtime.sendMessage({ type: "autoCapture" });



})();